-- all functions in this module will be available to use as long as we specify it in our register() hook


-- log helper as i am lazy
function log(group, msg)
  api_log(group, msg)
end
--ITEMS
--function define_item()
  --Mineral Propolis
  --api_define_item({
    --id = "mineral_propolis",
    --name = "Mineral Propolis",
    --category = "Beekeeping",
    --tooltip = "Propolis produced by a mineral bee. It is full of essential minerals that can be used to fortify your diet.",
    --shop_key = false,
    --shop_buy = 4,
    --shop_sell = 2,
  --}, "sprites/mineral_propolis.png")
--end
--BEES
function define_bee()
  --Mineral Bee 
  mineral_bee = {
    id = "mineral",
    title = "Mineral",
    latin = "Apis Mineralis",
    hint = "An uncommon relative of the rocky bee",
    desc = "This bee is the ancestor from which all other geological bees diverged.",
    lifespan = {"Normal"},
    productivity = {"Normal", "Fast"},
    fertility = {"Fecund", "Prolific"},
    stability = {"Normal", "Stable"},
    behaviour = {"Diurnal"},
    climate = {"Temperate"},
    rainlover = false,
    snowlover = false,
    grumpy = false,
    produce = "stone",
    --Below sectons of code will be utilized once more bees are added
    --recipes = {
    --  { a = "nightcrawler", b = "dream", s = "chaotic" }
    --},
    calming = {"flower10", "flower11"},
    chance = 100,
    bid = "X3",
    requirement = ""
  }
  -- create new bee
  -- in this example we have a "sprites" folder in our mod root
  api_define_bee(mineral_bee, 
    "sprites/mineral_bee_item.png", "sprites/mineral_bee_shiny.png", 
    "sprites/mineral_bee_hd.png",
    {r=100, g=100, b=100},
    "sprites/mineral_bee_mag.png",
    "Local Beekeeper Does It Again!",
    "Local APICO beekeeper restores the Mineral bee to its former glory!"
  );
  -- add a new mutation for our new bee
  api_define_bee_recipe("uncommon", "rocky", "mineral", "mutation_chance")
  -- add a new bee trait including our newly defined bee
  api_define_trait("magic", {
    common = {"low"}, 
    dream  = {"low", "medium"}, 
    mineral = {"high"}
  }, {"none"}) -- default for all the other bees
end


-- define the mutation critera/chance for our new bee
function mutation_chance(bee_a, bee_b)
  -- rocky-dream 30% chance at night to mutate
  if (bee_a == "rocky" and bee_b == "uncommon") or (bee_a == "uncommon" and bee_b == "rocky") then
    chance = api_random(99) + 1
    if chance <= 40 then
      return true
    end
  end
  return false;
end

